#!/usr/bin/env python
# coding: utf-8

# In[1]:

# import tensorflow as tf
# config = tf.ConfigProto()
# config.gpu_options.allow_growth=True
# sess = tf.Session(config=config)

import optuna
import pandas as pd
import numpy as np
import keras
import time

from keras.backend import clear_session
from keras.datasets import mnist
from keras.layers import Conv2D
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers import Input
from keras.layers import Activation
from keras.layers import Dropout
from keras.models import Sequential
from keras.optimizers import RMSprop
from keras.models import Sequential, load_model, Model
from keras.callbacks import EarlyStopping, ModelCheckpoint

from sklearn.model_selection import train_test_split
from sklearn.metrics import matthews_corrcoef
from sklearn.metrics import r2_score
from sklearn.ensemble import RandomForestRegressor

import os
os.environ["CUDA_VISIBLE_DEVICES"]="0"


# In[2]:


from sklearn.metrics import confusion_matrix

def metrics_eachClass(y_true,y_pred,printed=True):
    RESULT = []
    for c in np.unique(y_true):
        true = (y_true==c)*1
        pred = (y_pred==c)*1
        tn, fp, fn, tp = confusion_matrix(true,pred).ravel()
        Pr,Re,F1 = 0,0,0
        if (fp+tp):
            Pr = tp/(fp+tp)
        if (fn+tp):
            Re = tp/(fn+tp)
        if (2*tp+fp+fn):
            F1 = 2*tp/(2*tp+fp+fn)
        Acc = (tn+tp)/(tn+fp+fn+tp)
        Support = 100*sum(true)/len(true)
        try: mcc = matthews_corrcoef(true,pred)  
        except: mcc = 0.0
       
        result = (c,Support,tp,fp,tn,fn,mcc,Acc,Pr,Re,F1)
        if printed:
            s = '+ CLASE %d (%.3f) | [tp,fp,tn,fn] = [%d,%d,%d,%d] | MCC = %.3f | Acc = %.3f | Pr = %.3f | Re = %.3f | F1 = %.3f'
            print( s % result)
        RESULT.append({'CLASE':c,
                       'tp':tp,'fp':fp,'tn':tn,'fn':fn,
                       'matthews_corrcoef':mcc,
                       'Accuracy':Acc,
                       'Precision':Pr,
                       'Recall':Re,
                       'F1':F1,
                       'Support':Support})
    if printed:
        print(' TOTAL ACCURACY: %.3f' % (sum([y_true[i]==y_pred[i] for i in range(len(y_true))])/len(y_true)))
        print(' TOTAL MATTHEWS CORR COEF: %.3f' % matthews_corrcoef(y_true,y_pred))
    return RESULT


# In[3]:

import os 
path = os.path.abspath(__file__ + "/../../")

folder_data = path+ "/Datos/fenologia_vid_procesado.csv"
temp = pd.read_csv(folder_data,sep=';')
temp


# In[4]:


cols_usar=['fecha','season','dia','tmed_min', 'tmed_max','tmed_mean', 'rad_min', 'rad_max', 'rad_mean','potentialDormancyDay',
           'gdd_4.5_t0_Tbase_sum','gdd_4.5_t0_TbaseMax_sum', 'gdd_4.5_1_Tbase_sum','gdd_4.5_1_TbaseMax_sum', 'gdd_4.5_2_Tbase_sum','gdd_4.5_2_TbaseMax_sum', 
           'gdd_10.0_t0_Tbase_sum','gdd_10.0_t0_TbaseMax_sum', 'gdd_10.0_1_Tbase_sum','gdd_10.0_1_TbaseMax_sum', 'gdd_10.0_2_Tbase_sum','gdd_10.0_2_TbaseMax_sum', 
           'chillingDD_7.0_t0_Tbase_sum','chillingDD_7.0_t0_Tbasemin_sum', 'chillingDD_7.0_t0_Utah_sum','chillingDD_7.0_1_Tbase_sum', 'chillingDD_7.0_1_Tbasemin_sum','chillingDD_7.0_1_Utah_sum', 'chillingDD_7.0_2_Tbase_sum','chillingDD_7.0_2_Tbasemin_sum', 'chillingDD_7.0_2_Utah_sum', 
           'rad_sum','precip_sum', 
           'winkler_4.5_Tbase', 'winkler_4.5_TbaseMax','winkler_10.0_Tbase', 'winkler_10.0_TbaseMax',
           'gdd_4.5_t0_Tbase_sum_Cumm', 'gdd_4.5_t0_TbaseMax_sum_Cumm','gdd_4.5_1_Tbase_sum_Cumm', 'gdd_4.5_1_TbaseMax_sum_Cumm','gdd_4.5_2_Tbase_sum_Cumm', 'gdd_4.5_2_TbaseMax_sum_Cumm',
           'gdd_10.0_t0_Tbase_sum_Cumm', 'gdd_10.0_t0_TbaseMax_sum_Cumm','gdd_10.0_1_Tbase_sum_Cumm','gdd_10.0_1_TbaseMax_sum_Cumm', 'gdd_10.0_2_Tbase_sum_Cumm','gdd_10.0_2_TbaseMax_sum_Cumm', 
           'chillingDD_7.0_t0_Tbase_sum_Cumm','chillingDD_7.0_t0_Tbasemin_sum_Cumm','chillingDD_7.0_t0_Utah_sum_Cumm', 'chillingDD_7.0_1_Tbase_sum_Cumm','chillingDD_7.0_1_Tbasemin_sum_Cumm', 'chillingDD_7.0_1_Utah_sum_Cumm','chillingDD_7.0_2_Tbase_sum_Cumm', 'chillingDD_7.0_2_Tbasemin_sum_Cumm','chillingDD_7.0_2_Utah_sum_Cumm', 
           'rad__t0__Cumm', 'rad__1__Cumm','rad__2__Cumm', 'precip__t0__Cumm', 'precip__1__Cumm','precip__2__Cumm', 
           'winkler_4.5_t0_Tbase_Cumm','winkler_4.5_t0_TbaseMax_Cumm', 'winkler_4.5_1_Tbase_Cumm','winkler_4.5_1_TbaseMax_Cumm', 'winkler_4.5_2_Tbase_Cumm','winkler_4.5_2_TbaseMax_Cumm', 
           'winkler_10.0_t0_Tbase_Cumm','winkler_10.0_t0_TbaseMax_Cumm', 'winkler_10.0_1_Tbase_Cumm','winkler_10.0_1_TbaseMax_Cumm', 'winkler_10.0_2_Tbase_Cumm','winkler_10.0_2_TbaseMax_Cumm', 
           'wind_N', 'wind_NE', 'wind_E','wind_SE', 'wind_S', 'wind_SW', 'wind_W', 'wind_NW', 
           'SeasonDay_t0','SeasonDay_1', 'SeasonDay_2',
#            'codigo', 'especie', 'variedad',
           'Parcel_longitude', 'Parcel_latitude', 'Parcel_altitude',
           'grapevineParcelID',
           'grapevineState']
temp=temp.loc[temp[cols_usar].drop_duplicates().index]


# In[5]:


temp=temp.replace({'Cabernet-Sauvignon':'CABERNET SAUVIGNON', 'Garnacha-Blanca':'GARNACHA BLANCA', 'Mazuela':'MAZUELA', 
                   'Syrah':'SYRACH', 'Chardonnay':'CHARDONNAY', 'Merlot':'MERLOT', 'Tempranillo':'TEMPRANILLO'})
temp=temp[~temp.variedad.isna()]


# In[7]:


temp=pd.get_dummies(temp,columns=['variedad'])


# In[8]:


variedades=[col for col in temp.columns if 'variedad_' in col]


# In[10]:


temp['fecha']=pd.to_datetime(temp.fecha,format='%Y-%m-%d')


# In[11]:


temp=temp.sort_values(by=['fecha'],axis=0)


# In[12]:


temp=temp.set_index('fecha')


# In[13]:


malos=[]
for campaña in temp.season.unique():
    datos_camp=temp[temp['season']==campaña]
    for id_terr in datos_camp.grapevineParcelID.unique():
        datos_camp_terr=datos_camp[datos_camp['grapevineParcelID']==id_terr]
        datos_camp_terr_val=datos_camp_terr.grapevineState
        if(np.sum((datos_camp_terr_val.diff(1).iloc[1:]<0))>1):
            print(id_terr)
            malos.append(id_terr)


# In[14]:


buenos=[]
for campaña in temp.season.unique():
    print(campaña)
    datos_camp=temp[temp['season']==campaña]
    for id_terr in datos_camp.grapevineParcelID.unique():
        if(id_terr in np.unique(malos)):
            datos_camp_terr=datos_camp[datos_camp['grapevineParcelID']==id_terr]
            datos_camp_terr_val=datos_camp_terr.grapevineState
            if(np.sum((datos_camp_terr_val.diff(1).iloc[1:]<0))>1):
                for i in range(len(datos_camp_terr_val.diff(1).iloc[1:])-1):
                    if (datos_camp_terr_val.diff(1)[i+1]+datos_camp_terr_val.diff(1)[i+2]==0):
                        datos_camp_terr.loc[datos_camp_terr_val.index[i+1],'grapevineState']=datos_camp_terr.loc[datos_camp_terr_val.index[i+2],'grapevineState']
                datos_camp_terr_val=datos_camp_terr.grapevineState
                if(np.sum((datos_camp_terr_val.diff(1).iloc[1:]<0))<=1):
                    buenos.append(datos_camp_terr)
        else:
            buenos.append(datos_camp_terr)
                
temp=pd.concat(buenos)        


# In[15]:


def objective(trial,train,vali,variedades,estado_fen):
    variables_basic=['grapevineState']+variedades
    medidas=variables_basic#[]
    inicio=trial.suggest_categorical('Inicio mediciones',['t0','1','2'])
    temperatura_inicio=trial.suggest_categorical('Temperatura inicio',['10.0','4.5'])
    tbase=trial.suggest_categorical('Tbase',['Tbase','TbaseMax'])
    if(trial.suggest_categorical('Dia',[True,False])):
        medidas=medidas+['dia','SeasonDay_'+inicio]
        
    if(trial.suggest_categorical('Temperatura',[True,False])):
        medidas=medidas+['tmed_min', 'tmed_max','tmed_mean']
    if(trial.suggest_categorical('Viento',[True,False])):
        medidas=medidas+['wind_N', 'wind_NE', 'wind_E','wind_SE', 'wind_S', 'wind_SW', 'wind_W', 'wind_NW']
    if(trial.suggest_categorical('Radiacion',[True,False])):
        if(trial.suggest_categorical('Radiacion acumulada',[True,False])):
            medidas=medidas+['rad__'+inicio+'__Cumm']
        if(trial.suggest_categorical('Radiacion instantanea',[True,False])):
            medidas=medidas+['rad_min', 'rad_max', 'rad_mean','rad_sum']
    if(trial.suggest_categorical('Precipitaciones',[True,False])):
        if(trial.suggest_categorical('Precipitaciones acumuladas',[True,False])):
            medidas=medidas+['precip__'+inicio+'__Cumm']
        if(trial.suggest_categorical('Precipitacion instantanea',[True,False])):
            medidas=medidas+['precip_sum']
        
    if(trial.suggest_categorical('Latencia',[True,False])):
        medidas=medidas+['potentialDormancyDay']
    
    altitud=trial.suggest_categorical('Altitud',[True,False])
    latitud=trial.suggest_categorical('Latitud',[True,False])
    longitud=trial.suggest_categorical('Longitud',[True,False])
    
    if(longitud):
        medidas.append('Parcel_longitude')
    if(latitud):
        medidas.append('Parcel_latitude')
    if(altitud):
        medidas.append('Parcel_altitude')
        
    if(trial.suggest_categorical('Estación',[True,False])):
        if(longitud):
            medidas.append('stationLongitude')
        if(latitud):
            medidas.append('stationLatitude')
        if(altitud):
            medidas.append('stationAltitude')
        
    if(trial.suggest_categorical('Winkler',[True,False])):
        if(trial.suggest_categorical('Winkler base',[True,False])):
            medidas=medidas+['winkler_'+temperatura_inicio+'_'+tbase]
        if(trial.suggest_categorical('Winkler acumulado',[True,False])):
            medidas=medidas+['winkler_'+temperatura_inicio+'_'+inicio+'_'+tbase+'_Cumm']
            
    if(trial.suggest_categorical('Chilling',[True,False])):
        if(trial.suggest_categorical('Chilling base',[True,False])):
            medidas=medidas+['chillingDD_7.0_'+inicio+'_Tbase_sum','chillingDD_7.0_'+inicio+'_Tbasemin_sum', 
                             'chillingDD_7.0_'+inicio+'_Utah_sum']
        if(trial.suggest_categorical('Chilling acumulado',[True,False])):
            medidas=medidas+['chillingDD_7.0_'+inicio+'_Tbase_sum_Cumm', 'chillingDD_7.0_'+inicio+'_Tbasemin_sum_Cumm',
                             'chillingDD_7.0_'+inicio+'_Utah_sum_Cumm']
    
    if(trial.suggest_categorical('GDD',[True,False])):
        if(trial.suggest_categorical('GDD base',[True,False])):
            medidas=medidas+['gdd_'+temperatura_inicio+'_'+inicio+'_'+tbase+'_sum']
        if(trial.suggest_categorical('GDD acumulado',[True,False])):
            medidas=medidas+['gdd_'+temperatura_inicio+'_'+inicio+'_'+tbase+'_sum_Cumm']

    medidas.append('Dias hasta')
    train=train[(train['Dias hasta'].notnull()) & 
          (train['grapevineState'].notnull())][medidas]
    vali=vali[(vali['Dias hasta'].notnull()) & 
          (vali['grapevineState'].notnull())][medidas]

    train=train.dropna()
    vali=vali.dropna()

    X_train=train.drop(['Dias hasta'], axis=1).values
    Y_train=train['Dias hasta'].values
    X_vali=vali.drop(['Dias hasta'], axis=1).values
    Y_vali=vali['Dias hasta'].values

    clear_session()
    
      
    inputA = Input(shape=(X_train.shape[1],), name='Entrada')

    y = Dense(int(trial.suggest_discrete_uniform('Neuronas capa 0',low=16,high=512,q=16)))(inputA)
    y = Activation(trial.suggest_categorical('Activacion capa 0',["selu","linear","tanh","softmax"]))(y)
    
    capas=trial.suggest_int('Numero de capas',low=2,high=10)
    
    for i in range(1,capas):
        y = Dense(int(trial.suggest_discrete_uniform('Neuronas capa {}'.format(i),low=16,high=512,q=16)))(y)
        y = Activation(trial.suggest_categorical('Activacion capa {}'.format(i),["selu","linear","tanh","softmax"]))(y)
        
#     z = Dense(y_train.shape[1], activation="softmax")(y)
    z = Dense(1, activation="selu")(y)

    model = Model(inputs=inputA, outputs=z)
   
    
    model_data = path + "/Datos/Modelos/checkpointed_model.h5"
 
    callback = [EarlyStopping(monitor='val_loss',patience=17*2, min_delta=0.00017,restore_best_weights=False),
            ModelCheckpoint(model_data, monitor='val_loss',
                            save_best_only=True)]
    
    learning_rate=trial.suggest_categorical('Learning rate',[10**-3, 10**-2, 10**-1])
   
    choiceval = trial.suggest_categorical('Optimizador',['sgd','adam','rmsprop'])
    if choiceval == 'adam':
        optim = keras.optimizers.Adam(lr=learning_rate)
    elif choiceval == 'rmsprop':
        optim = keras.optimizers.RMSprop(lr=learning_rate)
    else:
        optim = keras.optimizers.SGD(lr=learning_rate)

    weights=None
    
    sample_weights=((Y_train>=7)&(Y_train<=21)).astype(int)*10+((Y_train<=60)).astype(int)*6+1
    
    model.save(path +'/Datos/Modelos/checkpointed_model.h5')
    
    model.compile(loss='mse', optimizer=optim, metrics=['mse'])
    model.fit(X_train, Y_train, epochs=1000, verbose=0, 
              batch_size=trial.suggest_int('Batch size',low=1,high=16), 
              callbacks=callback, validation_split=0.2, class_weight=weights, sample_weight=sample_weights)
    
    model=load_model(path + '/Datos/Modelos/checkpointed_model.h5')
        
    
    preds = model.predict(X_vali)

    #resu=metrics_eachClass(y_test,np.floor(preds))
    
    SCORE=r2_score(Y_vali,preds)
    print("R^2: ",SCORE)
    
    nombre=path + '/Datos/Modelos/NN/model-estado'+ str(estado_fen) +'-v2-'+str(SCORE)
     
    if SCORE>0.75:    
        model_json = model.to_json()
        with open(nombre+".json", "w") as json_file:
            json_file.write(model_json)
        model.save_weights(nombre+".h5")
    
    print('#'*100)
    
    return SCORE


# In[16]:


random_state  = 17
direction     = 'maximize'
n_trials      = 5
n_jobs        = 3
timeout       = None
verbosity     = 0
trozos=5

copia=temp.copy()

for estado_fen in temp.grapevineState.unique():
    if estado_fen in [1,3,4]:
        temp=copia.copy()
        temp=temp.reset_index()
        dias_hasta=[-17]*len(temp)
        for campaña in temp.season.unique():
            datos_camp=temp[temp['season']==campaña]
            for id_terr in datos_camp.grapevineParcelID.unique():
                datos_camp_terr=datos_camp[datos_camp['grapevineParcelID']==id_terr]
                x=datos_camp_terr[datos_camp_terr['grapevineState']>=estado_fen]['dia'].values
                endurecimiento=np.amin(x,where=(len(x)>0),initial=1000)
                if(endurecimiento!=1000):
                    for i in range(len(datos_camp_terr)):
                        #print(str(len(datos_camp_terr))+'-'+str(i))
                        if(datos_camp_terr['dia'].iloc[i]<endurecimiento):
                            dias_hasta[datos_camp_terr['dia'].index[i]]=(endurecimiento-datos_camp_terr['dia'].iloc[i])

        temp['Dias hasta']=dias_hasta
        temp=temp[(temp['Dias hasta']>0)]
        test=temp[temp.season=='2018_2019']
        test, vali = train_test_split(test, test_size=0.5, random_state=17)
        train=temp[temp.season!='2018_2019']

        study_name = f'Estado-'+str(estado_fen)
        sampler    = optuna.samplers.TPESampler(seed=random_state)
	
	
        FILE = f'{path}+/Datos/Modelos/NN/resumen_optuna-estado'+str(estado_fen)+'-r2-dias-v2.csv'

        study = optuna.create_study(study_name=study_name,direction=direction,sampler=sampler)

        for j in range(trozos):
            study.optimize(func=lambda trial: objective(trial,train,vali,variedades,estado_fen),
                           n_trials=n_trials,timeout=timeout)

            result_df = study.trials_dataframe()
            result_df.to_csv(FILE)
            time.sleep(12)
