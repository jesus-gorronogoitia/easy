#!/bin/bash
#
#SBATCH -t 0:10:00
#SBATCH -p gpu-shared
#SBATCH --gres gpu:1
#SBATCH --qos=urgent
#SBATCH --job-name my_python_code

module load miniconda3
conda activate tf_test

echo ===========================================================================
date
srun python /home/otras/gat/<username>/ITAINNOVA/Next_trials/Codigo/hard.py
date
echo ===========================================================================
